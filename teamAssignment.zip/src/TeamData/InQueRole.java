package TeamData;

public enum InQueRole {
    TANK, DAMAGE, SUPPORT,NODATA;
}
